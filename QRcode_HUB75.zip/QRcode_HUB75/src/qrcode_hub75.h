#ifndef ESPQRST7789_H
#define ESPQRST7789_H
/* ESP_QRcode. tft version for ST7789
 * include this .h if you have a TFT display
 */

#define HUB75

#include "qrcodedisplay.h"
#include <ESP32-HUB75-MatrixPanel-I2S-DMA.h>

class QRcode_HUB75 : public QRcodeDisplay
{
	private:
		MatrixPanel_I2S_DMA *display;
        void drawPixel(int x, int y, int color);
	public:
		
		QRcode_HUB75(MatrixPanel_I2S_DMA *display);

		void init();
		void init(uint16_t width, uint16_t height);
		void screenwhite();
		void screenupdate();
};
#endif