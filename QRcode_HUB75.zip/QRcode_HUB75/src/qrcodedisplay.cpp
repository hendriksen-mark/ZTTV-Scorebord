#include <Arduino.h>
#include "qrcodedisplay.h"
#include "qrencode.h"

void QRcodeDisplay::init() {
  // Default values
  this->offsetsX = 42;
  this->offsetsY = 10;
  this->screenwidth = 128;
  this->screenheight = 64;
  this->QRDEBUG = false;
  this->multiply = 1;
}

void QRcodeDisplay::init(uint16_t width, uint16_t height) {//64x32
  // Default values
  this->screenwidth = width;//64
  this->screenheight = height;//32
  this->QRDEBUG = false;
  int min = this->screenwidth;//64
  if (this->screenheight<this->screenwidth)//32<64
      min = this->screenheight;//32
  this->multiply = min/WD;//32/29=1.103448275862069
  this->offsetsX = (screenwidth - (WD*this->multiply))/2;//(64-(29*1.103448275862069))/2=16
  this->offsetsY = (screenheight - (WD*this->multiply))/2;//(32-(29*1.103448275862069))/2=0
}

void QRcodeDisplay::debug(){
	QRDEBUG = true;
}

void QRcodeDisplay::render(int x, int y, int color){
  x=(x*multiply)+offsetsX;
  y=(y*multiply)+offsetsY;
  this->drawPixel(x,y,color);
}

void QRcodeDisplay::create(String message) {
  // create QR code
  message.toCharArray((char *)strinbuf,260);
  qrencode();
  this->screenwhite();
  
  // print QR Code
  for (byte x = 0; x < WD; x+=2) {
    for (byte y = 0; y < WD; y++) {
      if ( QRBIT(x,y) &&  QRBIT((x+1),y)) {
        // black square on top of black square
        this->render(x, y, 1);
        this->render((x+1), y, 1);
      }
      if (!QRBIT(x,y) &&  QRBIT((x+1),y)) {
        // white square on top of black square
        this->render(x, y, 0);
        this->render((x+1), y, 1);
      }
      if ( QRBIT(x,y) && !QRBIT((x+1),y)) {
        // black square on top of white square
        this->render(x, y, 1);
        this->render((x+1), y, 0);
      }
      if (!QRBIT(x,y) && !QRBIT((x+1),y)) {
        // white square on top of white square
        this->render(x, y, 0);
        this->render((x+1), y, 0);
      }
    }
  }
  this->screenupdate();
}
